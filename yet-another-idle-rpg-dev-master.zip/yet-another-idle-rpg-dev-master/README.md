# yet another idle rpg


### Currently in a very early stage of development. 

Official repo: https://github.com/miktaew/yet-another-idle-rpg  
Official release: https://miktaew.github.io/yet-another-idle-rpg/  
  
  
Dev repo: https://github.com/miktaew/yet-another-idle-rpg-dev  
Dev release: https://miktaew.github.io/yet-another-idle-rpg-dev/  
  

Expect complete lack of gameplay balance and a lot of bugs, some potentialy gamebreaking.  
Using the "export" feature every now and then is highly recommended.